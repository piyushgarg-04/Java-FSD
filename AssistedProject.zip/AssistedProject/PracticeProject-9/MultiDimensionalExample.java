package PracticeProject9;

public class MultiDimensionalExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr1[][] = {{1,2,3},{4,9,8}};
		for(int i=0; i<2;i++) {
			for(int j=0; j<3; j++) {
				System.out.println(arr1[i][j]+" ");
			}
			System.out.println();
		}

	}

}
