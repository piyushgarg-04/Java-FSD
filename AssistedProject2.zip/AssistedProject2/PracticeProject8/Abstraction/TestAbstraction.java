package Abstraction;

public class TestAbstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s1 = new Circle(12,"red");
		Shape s2 = new Rectangle("red",12,5);
		System.out.println(s1);
		System.out.println(s2);
		

	}

}
