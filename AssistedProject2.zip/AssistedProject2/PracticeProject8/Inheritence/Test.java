package Inheritence;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MountainBike mb=  new MountainBike(25, 100, 20);
		System.out.println("Details: "+mb);

	}

}
