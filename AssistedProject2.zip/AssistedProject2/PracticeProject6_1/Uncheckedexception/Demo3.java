package Uncheckedexception;
//runtime: ArrayIndexOutOfBoundsException:

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]= {1,2,3,4};
		System.out.println(arr[4]);

	}

}
