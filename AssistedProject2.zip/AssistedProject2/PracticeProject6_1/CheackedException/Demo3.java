package CheackedException;
import java.io.FileReader;

public class Demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//compiletime :  FileNotFoundException
		FileReader file= new FileReader("C://test//user.txt");

	}

}
