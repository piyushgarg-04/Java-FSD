package CheackedException;

public class Demo1 {
      
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Exception in thread "main" java.lang.Error: Unresolved compilation problem:
		//The method print() is undefined for the type Demo1
		
		print();

	}

}
