package CheackedException;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
		//Type mismatch: cannot convert from double to int
		
		int a =33.3;
		System.out.println(a);

	}

}
