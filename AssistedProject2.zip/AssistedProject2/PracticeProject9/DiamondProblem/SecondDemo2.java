package DiamondProblem;

public interface SecondDemo2 {
	public default void Disp() {
		System.out.println("hello second interface");
	}

}
