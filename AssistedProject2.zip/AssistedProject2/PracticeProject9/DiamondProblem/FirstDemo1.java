package DiamondProblem;

public interface FirstDemo1 {
	
	public default void Disp() {
		System.out.println("This is my first  interface method");

}
}
